# Redux Practice Exercise

### Set up

`npm install`

### Running the test

`npm test`
