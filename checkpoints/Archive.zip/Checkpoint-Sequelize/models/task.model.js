'use strict';

const db = require('./database');
const Sequelize = require('sequelize');
const Op = Sequelize.Op;

// Make sure you have `postgres` running!

//---------VVVV---------  your code below  ---------VVV----------

const Task = db.define('Task', {
    name: {
        type: Sequelize.STRING,
        allowNull: false,
        validate: {
            notEmpty: true,
        },
    },
    complete: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
    },
    due: Sequelize.DATE,
});

Task.clearCompleted = function() {
    return Task.destroy({
        where: {
            complete: true,
        },
    });
};

Task.completeAll = function() {
    return Task.update({
        complete: true,
    }, {
        where: {
            complete: false,
        },
    });
};

Task.prototype.getTimeRemaining = function() {
    const data = this.dataValues;
    if (!data.due) {
        return Infinity;
    } else {
        let strTime = JSON.stringify(data.due);
        const startDate = strTime.slice(0, 11);
        let today = new Date();
        today = JSON.stringify(today).slice(0, 11);
        const timeDiff = new Date(startDate) - new Date(today);
        return timeDiff;
    }
};

Task.prototype.isOverdue = function() {
    const data = this.dataValues;
    const dueDate = data.due;
    const dueDateStr = JSON.stringify(dueDate);
    const startDate = dueDateStr.slice(0, 11);
    let today = new Date();
    today = JSON.stringify(today).slice(0, 11);

    if (this.dataValues.complete) return false;
    if (new Date(today) < new Date(startDate)) {
        return false;
    } else {
        return true;
    }
};

Task.prototype.addChild = async function(obj) {
    obj.parentId = this.dataValues.id;
    const task = await Task.create(obj);
    return task;
};

Task.prototype.getChildren = async function() {
    const children = await Task.findAll({
        where: {
            parentId: this.dataValues.id,
        },
    });
    return children;
};

Task.prototype.getSiblings = async function() {
    const targetId = this.dataValues.parentId;
    const siblings = await Task.findAll({
        where: {
            parentId: targetId,
            id: { $ne: this.dataValues.id },
        },
    });
    return siblings;
};

Task.belongsTo(Task, { as: 'parent' });

//---------^^^---------  your code above  ---------^^^----------

module.exports = Task;