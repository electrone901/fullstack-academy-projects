import React from 'react';

export default function AdoptionForm(props) {
  return (
    <div>
      <button onClick={props.adoptSelectedPet}>
        <select name="pets" id="" onChange={props.previewPet}>
          {props.pets.map((pet) => {
            return <option key={pet.name}>{pet.name}</option>;
          })}
        </select>
      </button>
    </div>
  );
}
