import React, { Component } from 'react';
import AdoptionForm from './AdoptionForm';

export default class PetPreview extends Component {
  constructor() {
    super();

    this.state = {
      petToPreview: {},
    };
    this.previewPet = this.previewPet.bind(this);
    this.adoptSelectedPet = this.adoptSelectedPet.bind(this);
  }

  previewPet(e) {
    const petArray = this.props.pets;
    const dog = petArray.find((ele) => ele.name === e.target.value);
    this.setState({ petToPreview: dog });
  }

  adoptSelectedPet() {
    this.props.adoptPet(this.state.petToPreview);
  }

  render() {
    return (
      <div className="preview">
        <div>
          <h5> Preview: </h5> <img src={this.state.petToPreview.imgUrl} />
          <AdoptionForm
            pets={this.props.pets}
            previewPet={this.previewPet}
            adoptSelectedPet={this.adoptSelectedPet}
          />
        </div>
      </div>
    );
  }
}
